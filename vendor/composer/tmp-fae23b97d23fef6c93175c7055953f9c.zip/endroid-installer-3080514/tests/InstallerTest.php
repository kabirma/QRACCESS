<?php

declare(strict_types=1);

namespace Endroid\Installer\Tests;

use PHPUnit\Framework\TestCase;

final class InstallerTest extends TestCase
{
    public function testNoTestsYet(): void
    {
        $this->assertTrue(true);
    }
}
